# @/components/Loader

![MIT license](https://badgen.now.sh/badge/license/MIT)

[Source](https://github.com/xizon/fullstack-nextjs-app-template/tree/main/src/components/Loader)


## Examples

```js
import Loader from '@/components/Loader';

export default () => {
  return (
    <>
		<Loader />
    </>
  );
}

```