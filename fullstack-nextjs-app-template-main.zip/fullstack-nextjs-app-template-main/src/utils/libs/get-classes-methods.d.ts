/**
 * Get All Methods of Classes
 * @param {Constructor} obj - Base Classes
 * @returns Array
 */
export function getClassesMethods(obj: Constructor): any[];
